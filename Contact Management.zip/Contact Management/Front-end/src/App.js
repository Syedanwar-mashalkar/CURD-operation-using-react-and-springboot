import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Button, Container, TextField, CircularProgress, Snackbar, Card, CardContent, IconButton } from '@mui/material';
import MuiAlert from '@mui/material/Alert';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon, Search as SearchIcon, Clear as ClearIcon } from '@mui/icons-material';
import axios from 'axios';
import ContactList from './ContactList';
import ContactForm from './ContactForm';
import ContactUpdate from './ContactUpdate';
import './App.css';

const Alert = React.forwardRef((props, ref) => {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function App() {
  const [contacts, setContacts] = React.useState([]);
  const [selectedContact, setSelectedContact] = React.useState(null);
  const [contactId, setContactId] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [searchActive, setSearchActive] = React.useState(false);
  const [msg, setMsg] = React.useState(null);

  const handleSearch = (e) => {
    e.preventDefault();
    if (!contactId) return;

    setLoading(true);
    setError(null);
    setSearchActive(true);

    axios.get(`http://localhost:8080/api/contacts/${contactId}`)
      .then((response) => {
        setContacts([response.data]);
        setLoading(false);
      })
      .catch((error) => {
        setError('There was an error fetching the contact!');
        setLoading(false);
        console.error('Error:', error);
      });
  };

  const handleClearSearch = () => {
    setSelectedContact(null);
    setContactId('');
    setSearchActive(false);
    setContacts([]);
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:8080/api/contacts/${id}`)
      .then(() => {
        setMsg('Successfully Deleted');
        setContacts(contacts.filter(contact => contact.id !== id));
        setSelectedContact(null);
      })
      .catch((error) => {
        setMsg('ID not matched or error occurred');
        console.error('Error:', error);
      });
  };

  const handleView = (contact) => {
    setSelectedContact(contact);
  };

  return (
    <Router>
      <div className="App">
        <AppBar position="static">
          <Toolbar>
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              <span style={{ fontWeight: 'bold', color: '#fff', fontSize: '24px' }}>Contact</span> <span style={{ fontSize: '18px' }}>CRUD</span>
            </Typography>
            
            <IconButton color="inherit" component={Link} to="/add" disabled={searchActive}>
              <AddIcon />
            </IconButton>
            <form onSubmit={handleSearch} style={{ display: 'flex', alignItems: 'center', marginLeft: 'auto' }}>
              <TextField
                label="Enter Name"
                value={contactId}
                onChange={(e) => setContactId(e.target.value)}
                variant="outlined"
                size="small"
                style={{ marginRight: '10px' }}
              />
              <Button type="submit" variant="contained" color="secondary" startIcon={<SearchIcon />}>
                Search
              </Button>
              {searchActive && (
                <Button onClick={handleClearSearch} variant="outlined" color="inherit" style={{ marginLeft: '10px' }} startIcon={<ClearIcon />}>
                  Clear
                </Button>
              )}
            </form>
          </Toolbar>
        </AppBar>
        <Container>
          {loading && <CircularProgress style={{ marginTop: '20px' }} />}
          {error && <Alert severity="error" style={{ marginTop: '20px' }}>{error}</Alert>}
          {msg && <Alert severity="success" style={{ marginTop: '20px' }}>{msg}</Alert>}
          {contacts.length > 0 && !loading && (
            <TableContainer component={Paper} style={{ marginTop: '20px' }}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>FirstName</TableCell>
                    <TableCell>Last Name</TableCell>
                    <TableCell>Phone Number</TableCell>
                    
                    
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {contacts.map((contact) => (
                    <TableRow key={contact.id}>
                      <TableCell>{contact.firstName}</TableCell>
                      <TableCell>{contact.lastName}</TableCell>
                      <TableCell>{contact.phoneNumber}</TableCell>
                      <TableCell>
                        <IconButton onClick={() => handleView(contact)} color="primary" style={{ marginRight: '10px' }}>
                          <SearchIcon />
                        </IconButton>
                        <IconButton component={Link} to={`/edit/${contact.id}`} color="secondary" style={{ marginRight: '10px' }}>
                          <EditIcon />
                        </IconButton>
                        <IconButton onClick={() => handleDelete(contact.id)} color="error">
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
          {!searchActive && (
            <Routes>
              <Route path="/" element={<ContactList />} />
              <Route path="/add" element={<ContactForm />} />
              <Route path="/edit/" element={<ContactUpdate />} />
            </Routes>
          )}
        </Container>
      </div>
    </Router>
  );
}

export default App;
