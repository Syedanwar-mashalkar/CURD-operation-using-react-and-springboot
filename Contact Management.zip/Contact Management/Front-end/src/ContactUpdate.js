import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { TextField, Button, Container, Typography } from '@mui/material';
import { useParams } from 'react-router-dom';

const ContactUpdate = () => {
  const { id } = useParams();
  const [name, setName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  useEffect(() => {
    axios.get(`/api/contacts/${id}`).then(response => {
      const contact = response.data;
      setName(contact.name);
      setLastName(contact.lastName);
      setPhoneNumber(contact.phoneNumber);
    });
  }, [id]);

  const handleUpdateContact = () => {
    const updatedContact = { name, lastName, phoneNumber };
    axios.put(`/api/contacts/${id}`, updatedContact).then(response => {
      alert('Contact updated successfully!');
    });
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Update Contact
      </Typography>
      <TextField
        label="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Last Name"
        value={lastName}
        onChange={(e) => setLastName(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Phone Number"
        value={phoneNumber}
        onChange={(e) => setPhoneNumber(e.target.value)}
        fullWidth
        margin="normal"
      />
      <Button variant="contained" color="primary" onClick={handleUpdateContact}>
        Update Contact
      </Button>
    </Container>
  );
};

export default ContactUpdate;
