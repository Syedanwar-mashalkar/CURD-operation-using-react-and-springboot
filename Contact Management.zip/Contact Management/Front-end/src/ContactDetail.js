import React, { useState } from 'react';
import ContactService from './ContactService';

const ContactDetail = () => {
    const [contact, setContact] = useState(null);
    const [contactId, setContactId] = useState(''); // State for contact ID input
    const [loading, setLoading] = useState(false); // State for loading status
    const [error, setError] = useState(null); // State for error handling

    const handleSearch = (e) => {
        e.preventDefault();
        if (!contactId) return; // Skip if no ID is entered

        setLoading(true);
        setError(null); // Reset error before fetching

        ContactService.getContactByName(contactId)
            .then((response) => {
                setContact(response.data);
                setLoading(false);
            })
            .catch((error) => {
                setError('There was an error fetching the contact!');
                setLoading(false);
                console.error('Error:', error);
            });
    };

    return (
        <div className='list'>
            <h2>Search Contact</h2>
            <form onSubmit={handleSearch}>
                <label>
                    Enter Name:
                    <input
                        type="text"
                        value={contactId}
                        onChange={(e) => setContactId(e.target.value)}
                        placeholder="Enter ID"
                    />
                </label>
                <button type="submit">Search</button>
            </form>

            {loading && <p>Loading...</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {contact && !loading && (
                <div>
                    
                    <p><strong>Name:</strong> {contact.firstName}</p>
                    <p><strong>Email:</strong> {contact.email}</p>
                    <p><strong>Phone Number:</strong> {contact.phoneNumber}</p>
                </div>
            )}
        </div>
    );
};

export default ContactDetail;
