import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton, Dialog, DialogTitle, DialogContent, Typography, Avatar, TextField, Button } from '@mui/material';
import { Visibility as VisibilityIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { Link } from 'react-router-dom';

const ContactList = () => {
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [open, setOpen] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [contactToDelete, setContactToDelete] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false); // Track edit mode
  const [editForm, setEditForm] = useState({
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: '',
    dateOfBirth: '',
    address: '',
    city: '',
    state: '',
    gender: ''
  });

  useEffect(() => {
    axios.get('http://localhost:8080/api/contacts').then(response => {
      setContacts(response.data);
    });
  }, []);

  const handleEdit = () => {
    axios.put(`http://localhost:8080/api/contacts/${selectedContact.id}`, editForm)
      .then(() => {
        setContacts(contacts.map(contact => 
          contact.id === selectedContact.id ? { ...contact, ...editForm } : contact
        ));
        setOpen(false);
        setSelectedContact(null);
        setIsEditMode(false);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  const handleDelete = () => {
    axios.delete(`http://localhost:8080/api/contacts/${contactToDelete.id}`).then(() => {
      setContacts(contacts.filter(contact => contact.id !== contactToDelete.id));
      setOpenDeleteDialog(false);
      setContactToDelete(null);
    }).catch(error => {
      console.error('Error:', error);
    });
  };

  const handleOpenDeleteDialog = (contact) => {
    setContactToDelete(contact);
    setOpenDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setOpenDeleteDialog(false);
    setContactToDelete(null);
  };

  const handleView = (contact) => {
    setSelectedContact(contact);
    setEditForm({
      firstName: contact.firstName,
      lastName: contact.lastName,
      phoneNumber: contact.phoneNumber,
      email: contact.email,
      dateOfBirth: contact.dateOfBirth,
      address: contact.address,
      city: contact.city,
      state: contact.state,
      gender: contact.gender
    });
    setIsEditMode(false); // View mode
    setOpen(true);
  };

  const handleEditClick = (contact) => {
    setSelectedContact(contact);
    setEditForm({
      firstName: contact.firstName,
      lastName: contact.lastName,
      phoneNumber: contact.phoneNumber,
      email: contact.email,
      dateOfBirth: contact.dateOfBirth,
      address: contact.address,
      city: contact.city,
      state: contact.state,
      gender: contact.gender
    });
    setIsEditMode(true); // Edit mode
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedContact(null);
    setIsEditMode(false);
  };

  const handleChange = (e) => {
    setEditForm({
      ...editForm,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Profile Photo</TableCell>
              <TableCell>First Name</TableCell>
              <TableCell>Last Name</TableCell>
              <TableCell>Phone Number</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {contacts.map(contact => (
              <TableRow key={contact.id}>
                <TableCell>
                  <Avatar alt={`${contact.firstName} ${contact.lastName}`} src={contact.profilePhotoUrl || "/default-profile.png"} />
                </TableCell>
                <TableCell>{contact.firstName}</TableCell>
                <TableCell>{contact.lastName}</TableCell>
                <TableCell>{contact.phoneNumber}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleView(contact)} color="primary" style={{ marginRight: '10px' }}>
                    <VisibilityIcon />
                  </IconButton>
                  <IconButton onClick={() => handleEditClick(contact)} color="secondary" style={{ marginRight: '10px' }}>
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleOpenDeleteDialog(contact)} color="error">
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* View/Edit Contact Dialog */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{isEditMode ? 'Edit Contact' : 'Contact Details'}</DialogTitle>
        {selectedContact && (
          <DialogContent>
            {isEditMode ? (
              <>
                <TextField
                  label="First Name"
                  name="firstName"
                  value={editForm.firstName}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="Last Name"
                  name="lastName"
                  value={editForm.lastName}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="Phone Number"
                  name="phoneNumber"
                  value={editForm.phoneNumber}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="Email"
                  name="email"
                  value={editForm.email}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="Date of Birth"
                  name="dateOfBirth"
                  type="date"
                  value={editForm.dateOfBirth}
                  onChange={handleChange}
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  margin="normal"
                />
                <TextField
                  label="Address"
                  name="address"
                  value={editForm.address}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="City"
                  name="city"
                  value={editForm.city}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="State"
                  name="state"
                  value={editForm.state}
                  onChange={handleChange}
                  fullWidth
                  margin="normal"
                />
                <TextField
                  label="Gender"
                  name="gender"
                  select
                  value={editForm.gender}
                  onChange={handleChange}
                  fullWidth
                  SelectProps={{ native: true }}
                  margin="normal"
                >
                  <option value="" disabled>Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </TextField>
                <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end' }}>
                  <Button onClick={handleClose} color="inherit" style={{ marginRight: '10px' }}>
                    Cancel
                  </Button>
                  <Button onClick={handleEdit} color="primary">
                    Save
                  </Button>
                </div>
              </>
            ) : (
              <>
                <Avatar alt={`${selectedContact.firstName} ${selectedContact.lastName}`} src={selectedContact.profilePhotoUrl || "/default-profile.png"} style={{ width: 100, height: 100, marginBottom: '20px' }} />
                <Typography variant="body1"><strong>First Name:</strong> {selectedContact.firstName}</Typography>
                <Typography variant="body1"><strong>Last Name:</strong> {selectedContact.lastName}</Typography>
                <Typography variant="body1"><strong>Phone Number:</strong> {selectedContact.phoneNumber}</Typography>
                <Typography variant="body1"><strong>Email:</strong> {selectedContact.email}</Typography>
                <Typography variant="body1"><strong>Date of Birth:</strong> {new Date(selectedContact.dateOfBirth).toLocaleDateString()}</Typography>
                {/* <Typography variant="body1"><strong>Address:</strong> {selectedContact.address}</Typography> */}
                <Typography variant="body1"><strong>City:</strong> {selectedContact.city}</Typography>
                <Typography variant="body1"><strong>State:</strong> {selectedContact.state}</Typography>
                <Typography variant="body1"><strong>Gender:</strong> {selectedContact.gender}</Typography>
                <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end' }}>
                  <Button onClick={handleClose} color="primary">
                    Close
                  </Button>
                </div>
              </>
            )}
          </DialogContent>
        )}
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={openDeleteDialog} onClose={handleCloseDeleteDialog}>
        <DialogTitle>Confirm Deletion</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this contact?</Typography>
          <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end' }}>
            <Button onClick={handleCloseDeleteDialog} color="inherit" style={{ marginRight: '10px' }}>
              Cancel
            </Button>
            <Button onClick={handleDelete} color="error">
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ContactList;
