import React, { useState } from "react";
import ContactService from "./ContactService";

function ContactDelet() {
    const [msg, setMsg] = useState('');
    const [contactId, setContactId] = useState('');

    const deleteHandler = (e) => {
        e.preventDefault();
        if (contactId) {
            ContactService.deleteContact(contactId)
                .then((response) => {
                    alert('successfully Deleted');
                    setMsg('Successfully Deleted');
                    setContactId(''); // Clear the input field after success
                })
                .catch((error) => {
                    console.error('There was an error deleting the contact!', error);
                    setMsg('ID not matched or error occurred');
                });
        } else {
            setMsg('Please enter a contact ID');
        }
    };

    return (
        <div>
            <h1>Delete Contact by ID</h1>
            <form onSubmit={deleteHandler}>
                <input 
                    type="text" 
                    value={contactId}   
                    onChange={(e) => setContactId(e.target.value)} 
                    placeholder="Enter contact ID"
                />
                <button type="submit">Delete</button>
            </form>
            {msg && <p>{msg}</p>} {/* Display the message */}
        </div>
    );
}

export default ContactDelet;
